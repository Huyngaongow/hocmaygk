# Ví dụ Bagging xuyên suốt: từ dữ liệu đến quyết định

Dữ liệu dưới đây là **giả lập một chiều**, không phải ca bệnh thực tế. Dùng nhãn 0 = ác tính, 1 = lành tính để thống nhất ký hiệu với thí nghiệm chính.

## 1. Dữ liệu ban đầu

| Chỉ số i | Đặc trưng x | Nhãn y |
|---:|---:|---|
| 0 | 1 | 1: lành tính |
| 1 | 2 | 1: lành tính |
| 2 | 3 | 0: ác tính |
| 3 | 4 | 0: ác tính |
| 4 | 5 | 0: ác tính |

## 2. Bootstrap và học ba cây nhỏ

Mỗi mẫu có 5 lượt lấy **có hoàn lại** từ 5 quan sát. Ba dãy dưới đây được chọn cố định để có thể đối chiếu bằng tay; không phải ba tập rời nhau. Cây độ sâu 1 chọn ngưỡng giảm Gini nhiều nhất.

| Cây | Chỉ số bootstrap | Không có mặt | Ngưỡng học được | Gini trước | Gini sau |
|---|---|---|---:|---:|---:|
| h1 | [0, 0, 2, 4, 1] | [3] | 2.5 | 0.48 | 0.00 |
| h2 | [0, 0, 1, 3, 4] | [2] | 3 | 0.48 | 0.00 |
| h3 | [4, 2, 4, 1, 3] | [0] | 2.5 | 0.32 | 0.00 |

Với h1, bootstrap tạo các cặp: (1,lành), (1,lành), (3,ác), (5,ác), (2,lành).
Gini trước = 1 − (3/5)² − (2/5)² = 0,48. Ngưỡng 2,5 cho nhánh trái có 3 lành và nhánh phải có 2 ác; cả hai nhánh thuần nhất nên Gini sau = (3/5)×0 + (2/5)×0 = 0.
Mức giảm = 0.48. Ngưỡng này nằm giữa x=2 và x=3. Ngược lại, h2 không có x=3 nên chọn ngưỡng giữa x=2 và x=4, tức 3,0. Đó là cách bootstrap có thể tạo cây khác nhau.

## 3. Cùng dự đoán một mẫu mới x = 2,8

| Cây | Quy tắc đã học | Thay x=2,8 | Dự đoán |
|---|---|---|---|
| h1 | x ≤ 2.5: lành; còn lại: ác | 2,8 > 2.5 | ác tính (0) |
| h2 | x ≤ 3: lành; còn lại: ác | 2,8 ≤ 3 | lành tính (1) |
| h3 | x ≤ 2.5: lành; còn lại: ác | 2,8 > 2.5 | ác tính (0) |

Ba dự đoán **[0, 1, 0]** cho **2 phiếu ác, 1 phiếu lành**; hard voting chọn **ác tính (0)**.
Không có nhãn thật của mẫu mới nên chưa kết luận dự đoán đúng hay sai. 2/3 chỉ là tỷ lệ phiếu, không phải xác suất bệnh đã hiệu chỉnh.

## 4. Kiểm tra OOB trên chính năm mẫu train

| Chỉ số | Nhãn thật | Cây được bỏ phiếu OOB | Dự đoán OOB | Đúng? |
|---:|---|---|---|---|
| 0 | lành tính | h3 | lành tính | Có |
| 1 | lành tính | Không có | Không xác định | Không tính |
| 2 | ác tính | h2 | lành tính | Không |
| 3 | ác tính | h1 | ác tính | Có |
| 4 | ác tính | Không có | Không xác định | Không tính |

Mẫu 2 (x=3, nhãn ác) chỉ nhận phiếu từ h2 vì h1/h3 đã học mẫu đó. h2 dự đoán lành do 3 ≤ 3,0: đây là một lỗi OOB thật của ví dụ.
**Coverage = 3/5 = 60%; accuracy OOB = 2/3 ≈ 66,67%** trên ba mẫu có phiếu. Hai mẫu không có phiếu không bị coi là dự đoán lớp 0 hoặc tự động tính sai.

## 5. Điều cần rút ra

Bootstrap thay đổi dữ liệu mỗi cây; cây học ngưỡng khác nhau; voting kết hợp các dự đoán. OOB chỉ dùng những cây chưa học mẫu được đánh giá. Ba cây ở đây phục vụ tính tay, không dùng để suy ra hiệu năng của thí nghiệm 51 cây.
