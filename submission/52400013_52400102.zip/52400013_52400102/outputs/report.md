# Báo cáo thực nghiệm — Ensemble Learning

Seed tham chiếu: **42**; train: 426; test: 143; depth chọn trên train: **3**; số cây: 51.

Ác tính (malignant=0) là lớp dương. Hàng ma trận là nhãn thật, cột là dự đoán.

## Kết quả seed tham chiếu

| Mô hình | Accuracy | Precision ác | Recall ác | F1 ác | Bỏ sót ác |
|---|---:|---:|---:|---:|---:|
| Decision Tree | 94.41% | 94.12% | 90.57% | 92.31% | 5 |
| Manual Bagging | 95.10% | 94.23% | 92.45% | 93.33% | 4 |
| Random Forest (sklearn) | 95.10% | 94.23% | 92.45% | 93.33% | 4 |

## Độ ổn định giữa các lần chia

Mean ± SD mẫu (đơn vị %; SD tính bằng ddof=1). Một lần chạy: SD không xác định.

| Mô hình | Số lần | Accuracy mean ± SD | Recall ác mean ± SD | F1 ác mean ± SD |
|---|---:|---:|---:|---:|
| Decision Tree | 10 | 92.80 ± 1.84 | 90.38 ± 4.66 | 90.30 ± 2.42 |
| Manual Bagging | 10 | 94.76 ± 1.59 | 92.45 ± 3.77 | 92.89 ± 2.13 |
| Random Forest (sklearn) | 10 | 95.03 ± 1.85 | 92.26 ± 3.26 | 93.26 ± 2.39 |

Các tập test giữa các seed có thể giao nhau. SD mô tả độ biến thiên, không phải khoảng tin cậy độc lập.
Mỗi seed chọn lại depth bằng CV trên train của seed đó; không chọn seed tốt nhất dựa trên test.
Depth chọn bằng cây đơn rồi dùng chung cho ba mô hình, chưa tuning riêng từng ensemble.

## Out-of-bag (Bagging, seed tham chiếu)

- Accuracy OOB: 94.13%.
- Coverage: 100.00%; mẫu có phiếu: 426.
- Chỉ cây không thấy mẫu khi huấn luyện mới được bỏ phiếu OOB cho mẫu đó.
- Depth đã chọn trên train, nên OOB sau lựa chọn này không phải điểm kiểm định độc lập.

## Ví dụ bất đồng

Vị trí test 2, hàng dữ liệu gốc 291 (đếm từ 0).
Phiếu: {'malignant': 27, 'benign': 24}. Nhãn thật: benign; dự đoán: malignant; đúng: False.
Chọn mẫu bất đồng đầu tiên theo thứ tự test, không chọn theo dự đoán đúng.

Tỷ lệ phiếu không phải xác suất bệnh đã hiệu chỉnh. RF lấy trung bình xác suất cây, khác hard voting.
Đây là bài minh họa học máy, chưa xác thực lâm sàng.

## Tái lập

Phiên bản: xem results.json. Seeds: [42, 43, 44, 45, 46, 47, 48, 49, 50, 51].
Biểu đồ ma trận và voting thuộc seed tham chiếu; stability.png thuộc tất cả seed.
